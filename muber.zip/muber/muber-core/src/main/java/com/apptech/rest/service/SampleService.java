package com.apptech.rest.service;

import com.apptech.rest.annotation.DataWriteAble;
import com.google.inject.ImplementedBy;
import com.google.inject.Inject;
import org.skife.jdbi.v2.DBI;

import java.util.List;
import java.util.Map;

@ImplementedBy(SampleServiceImpl.class)
public interface SampleService {
    String foo();

    List<Map<String, Object>> getDataFromDb();

    Map<String, Object> UpdateUsingReadonly();

    Map<String, Object> UpdateUsingWriteable();
}
