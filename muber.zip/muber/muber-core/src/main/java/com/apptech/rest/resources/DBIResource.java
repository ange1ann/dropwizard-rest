package com.apptech.rest.resources;

import com.apptech.rest.service.DBIOperateService;
import com.apptech.rest.service.SampleService;
import com.google.inject.Inject;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;
import java.util.Map;

@Path("/dbi")
@Produces(MediaType.APPLICATION_JSON)
public class DBIResource {
    private final DBIOperateService service;

    @Inject
    public DBIResource(DBIOperateService service) {
        this.service = service;
    }

    @GET
    @Path("/execute")
    public Response writeSome() {
        service.executeSomething();
        return Response.ok("ABC").build();
    }

    @GET
    @Path("/procedure")
    public Response procedure() {
        List<Map<String,Object>> result = service.executeSomethingMulti();
        return Response.ok(result).build();
    }
}
