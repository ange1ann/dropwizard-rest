package com.apptech.rest.security;

public class TimberCredentials {
    private final String token;

    public TimberCredentials(String token) {
        this.token = token;
    }

    public String getToken() {
        return token;
    }

    @Override
    public String toString() { return token; }
}
