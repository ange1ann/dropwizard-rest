package com.apptech.rest.resources;

import com.apptech.rest.api.AuthedUser;
import com.apptech.rest.protos.AddressBookProtos;
import com.apptech.rest.security.TimberAuthResolver;
import com.codahale.metrics.annotation.Timed;
import com.google.common.io.Files;
import com.googlecode.protobuf.format.JsonFormat;
import io.dropwizard.auth.Auth;
import io.dropwizard.jersey.protobuf.ProtocolBufferMediaType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Path("/auth")
@Produces(MediaType.APPLICATION_JSON)
public class AuthResource {

    private static final Logger LOGGER = LoggerFactory.getLogger(AuthResource.class);

    @Timed
    @Path("jwt")
    @GET
    public Response testJwt() {
        long expireDays = 1800000;
        String jwtToken = TimberAuthResolver.createJsonWebToken("638000",expireDays);
        Map<String,String> data = new HashMap<>();
        data.put("jwt",jwtToken);
        return Response.ok(data).build();
    }

    @Timed
    @Path("user")
    @GET
    public Response testAuthUser(@Auth AuthedUser user)  {
        return Response.ok(user).build();
    }

    @Path("proto")
    @GET
    @Produces({ProtocolBufferMediaType.APPLICATION_PROTOBUF, MediaType.APPLICATION_JSON})
    public Response testProto(@Context HttpHeaders headers) throws IOException {
        AddressBookProtos.PersonFail.Builder personBuilder = AddressBookProtos.PersonFail.newBuilder();
        personBuilder.setId(123)
                .setName("ABC")
                .setEmail("test@qq.com")
                .addPhone(AddressBookProtos.PersonFail.PhoneNumber.newBuilder()
                        .setNumber("555-4321")
                        .setType(AddressBookProtos.PersonFail.PhoneType.HOME));
        AddressBookProtos.PersonFail msg = personBuilder.build();
        byte[] byteArray = msg.toByteArray();

        File file = new File("protobuf.txt");
        Files.write(byteArray, file);
        JsonFormat jsonFormat = new JsonFormat();
        String json = jsonFormat.printToString(msg);

        AddressBookProtos.PersonFail newPerson = AddressBookProtos.PersonFail.parseFrom(byteArray);

        List<MediaType> accepts = headers.getAcceptableMediaTypes();
        if (accepts.contains(ProtocolBufferMediaType.APPLICATION_PROTOBUF_TYPE)) {
            return Response.ok(msg, ProtocolBufferMediaType.APPLICATION_PROTOBUF).build();
        } else {
            // default
            return Response.ok(json, MediaType.APPLICATION_JSON).build();
        }
    }

    @Path("protooutput")
    @POST
    @Consumes("application/x-protobuf")
    @Produces("application/x-protobuf")
    public AddressBookProtos.PersonFail testProtobufByte(AddressBookProtos.PersonFail person) {
//        AddressBookProtos.PersonFail xxg2 = AddressBookProtos.PersonFail.parseFrom(input);
        LOGGER.info("Person:" + person);
        return person;
    }

}
