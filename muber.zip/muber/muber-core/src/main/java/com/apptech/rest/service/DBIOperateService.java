package com.apptech.rest.service;

import com.google.inject.ImplementedBy;

import java.util.List;
import java.util.Map;

@ImplementedBy(DBIOperateServiceImpl.class)
public interface DBIOperateService {
    void executeSomething();

    List<Map<String,Object>> executeSomethingMulti();
}
