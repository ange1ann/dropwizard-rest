package com.apptech.rest.service;

import com.google.inject.Inject;
import javassist.scopedpool.SoftValueHashMap;
import org.glassfish.jersey.message.internal.OutboundJaxrsResponse;
import org.skife.jdbi.v2.DBI;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DBIOperateServiceImpl implements DBIOperateService {
    private final DataBaseService dataBaseService;

    @Inject
    public DBIOperateServiceImpl(DataBaseService dataBaseService) {
        this.dataBaseService = dataBaseService;
    }


    @Override
    public void executeSomething() {
        DBI dbi=dataBaseService.getClient();
        Map<String,Object> params= new HashMap<>();
        params.put("id",6);
        dataBaseService.executeNonQuery(dbi,"UPDATE crm_t_user SET id=:id,systime = NOW();",params);
    }

    @Override
    public List<Map<String,Object>> executeSomethingMulti() {
        DBI dbi=dataBaseService.getClient();
        return dataBaseService.executeProcedure(dbi,"Name",null);
    }
}
