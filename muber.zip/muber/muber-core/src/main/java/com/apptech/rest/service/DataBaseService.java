package com.apptech.rest.service;

import com.google.inject.ImplementedBy;
import org.skife.jdbi.v2.DBI;

import java.util.List;
import java.util.Map;

@ImplementedBy(DataBaseServiceImpl.class)
public interface DataBaseService {
    DBI getClient();
    DBI getReadOnlyClient();

    void executeNonQuery(DBI jdbi, String querySql);

    void executeNonQuery(DBI jdbi, String commandSql, Map<String, Object> params);

    List<Map<String, Object>> executeProcedure(DBI jdbi, String procedureName, Map<String, Object> params);
}
