package com.apptech.rest.resources;

import com.apptech.rest.service.SampleService;
import com.google.inject.Inject;

import javax.annotation.security.PermitAll;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/sample")
@Produces(MediaType.APPLICATION_JSON)
@PermitAll
public class SampleResource {
    private final SampleService service;

    @Inject
    public SampleResource(SampleService service) {
        this.service = service;
    }

    @GET
    @Path("/foo")
    public Response latest() {
        return Response.ok(service.foo()).build();
    }

    @GET
    @Path("/persons")
    public Response persons() {
        return Response.ok(service.getDataFromDb()).build();
    }

    @GET
    @Path("/update")
    public Response updateing() {
        return Response.ok(service.UpdateUsingReadonly()).build();
    }

    @GET
    @Path("/write")
    public Response writeSome() {
        return Response.ok(service.UpdateUsingWriteable()).build();
    }
}
