package com.apptech.rest;

import com.apptech.rest.module.DataBaseModule;
import io.dropwizard.Application;
import io.dropwizard.setup.Bootstrap;
import io.dropwizard.setup.Environment;
import org.joda.time.DateTimeZone;
import ru.vyarus.dropwizard.guice.GuiceBundle;

public class TimberService extends Application<TimberConfiguration> {
    public static void main(String[] args) throws Exception {
        new TimberService().run("server", System.getProperty("dropwizard.config"));
    }

    @Override
    public void initialize(Bootstrap<TimberConfiguration> bootstrap) {
        DateTimeZone.setDefault(DateTimeZone.UTC);

        GuiceBundle<TimberConfiguration> guiceBundle = GuiceBundle.<TimberConfiguration>builder()
                .enableAutoConfig(getClass().getPackage().getName())
                .noGuiceFilter()
                .printDiagnosticInfo()
                .modules(new DataBaseModule())
                .build();
        bootstrap.addBundle(guiceBundle);
    }

    @Override
    public void run(TimberConfiguration configuration, Environment env) throws Exception {
    }
}
