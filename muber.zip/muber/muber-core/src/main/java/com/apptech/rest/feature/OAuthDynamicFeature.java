package com.apptech.rest.feature;

import com.apptech.rest.api.AuthedUser;
import com.apptech.rest.security.TimberAuthFilter;
import com.apptech.rest.security.TimberAuthenticator;
import com.google.inject.Inject;
import io.dropwizard.auth.AuthDynamicFeature;
import io.dropwizard.auth.AuthValueFactoryProvider;
import io.dropwizard.auth.PermitAllAuthorizer;
import io.dropwizard.setup.Environment;

import javax.ws.rs.ext.Provider;


@Provider
public class OAuthDynamicFeature extends AuthDynamicFeature {
    @Inject
    OAuthDynamicFeature(TimberAuthenticator authenticator, TimberAuthenticator authorizer, Environment environment) {
        super(new TimberAuthFilter.Builder()
                .setAuthenticator(authenticator)
                .setAuthorizer(new PermitAllAuthorizer<>())
                .setRealm("user")
                .buildAuthFilter());

        environment.jersey().register(new AuthValueFactoryProvider.Binder<>(AuthedUser.class));
    }
}
