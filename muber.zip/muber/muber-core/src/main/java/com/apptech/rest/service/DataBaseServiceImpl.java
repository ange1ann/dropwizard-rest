package com.apptech.rest.service;

import com.apptech.rest.annotation.DataReadOnly;
import com.apptech.rest.annotation.DataWriteAble;
import com.google.inject.Inject;
import org.skife.jdbi.cglib.core.ObjectSwitchCallback;
import org.skife.jdbi.v2.*;
import org.skife.jdbi.v2.tweak.HandleCallback;
import org.skife.jdbi.v2.util.StringColumnMapper;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class DataBaseServiceImpl implements DataBaseService {

    private final DBI readOnlyDBI;
    private final DBI writeAbleDBI;

    @Inject
    public DataBaseServiceImpl(@DataWriteAble DBI writeAbleDBI, @DataReadOnly DBI readOnlyDBI) {
        this.readOnlyDBI = readOnlyDBI;
        this.writeAbleDBI = writeAbleDBI;
    }

    @Override
    public DBI getClient() {
        return writeAbleDBI;
    }

    @Override
    public DBI getReadOnlyClient() {
        return readOnlyDBI;
    }

    @Override
    public void executeNonQuery(DBI jdbi, String commandSql) {
        jdbi.withHandle(new HandleCallback<Void>() {
            public Void withHandle(Handle handle) throws Exception {
                handle.execute(commandSql);
                return null;
            }
        });
    }

    /**
     * 执行语句，无返回结果
     *
     * @param jdbi
     * @param commandSql
     * @param params
     */
    public void executeNonQuery(DBI jdbi, String commandSql, Map<String, Object> params) {
        jdbi.withHandle(new HandleCallback<Void>() {
            public Void withHandle(Handle handle) throws Exception {
                handle.createStatement(commandSql).bindFromMap(params).execute();
                return null;
            }
        });
    }

    /**
     * 获取查询的第一条数据
     *
     * @param jdbi
     * @param commandSql
     * @param params
     * @return
     */
    public Map<String, Object> executeScalar(DBI jdbi, String commandSql, Map<String, Object> params) {
        return jdbi.withHandle(handle -> handle.createQuery(commandSql).bindFromMap(params).first());
    }

    /**
     * 获取单一查询结果集
     *
     * @param jdbi
     * @param commandSql
     * @param params
     * @return
     */
    public List<Map<String, Object>> executeQuery(DBI jdbi, String commandSql, Map<String, Object> params) {
        return jdbi.withHandle(handle -> handle.createQuery(commandSql).bindFromMap(params).list());
    }

    /**
     * 获取单一查询结果集的前N条数据
     *
     * @param jdbi
     * @param commandSql
     * @param params
     * @param maxRows
     * @return
     */
    public List<Map<String, Object>> executeQuery(DBI jdbi, String commandSql, Map<String, Object> params, int maxRows) {
        return jdbi.withHandle(handle -> handle.createQuery(commandSql).bindFromMap(params).list(maxRows));
    }

    /**
     * 批量执行不同的SQL语句
     *
     * @param jdbi
     * @param commandSqlList
     * @return
     */
    public int[] executeBatch(DBI jdbi, List<String> commandSqlList) {
        return jdbi.withHandle(handle -> {
            Batch batch = handle.createBatch();
            commandSqlList.forEach(batch::add);

            try {
                handle.begin();
                int[] resultSets = batch.execute();
                handle.commit();
                return resultSets;
            } catch (Exception e) {
                handle.rollback();
                throw e;
            }
        });
    }

    /**
     * 批量执行相同的SQL语句
     *
     * @param jdbi
     * @param commandSql
     * @param params
     * @return
     */
    public int[] executeBatch(DBI jdbi, String commandSql, List<Map<String, Object>> params) {
        return jdbi.withHandle(handle -> {
            PreparedBatch batch = handle.prepareBatch(commandSql);
            if (params != null) {
                params.forEach(batch::bindFromMap);
            }

            try {
                handle.begin();
                int[] resultSets = batch.execute();
                handle.commit();
                return resultSets;
            } catch (Exception e) {
                handle.rollback();
                throw e;
            }
        });
    }

    /**
     * example ":x = CALL TO_DEGREES(:y)"
     *
     * @param jdbi
     * @param params
     */
    public List<Map<String, Object>> executeProcedure(DBI jdbi, String procedureName, Map<String, Object> params) {
        return jdbi.withHandle(new HandleCallback<List<Map<String, Object>>>() {
            public List<Map<String, Object>> withHandle(Handle handle) throws Exception {
                Query<Map<String, Object>> allResult = handle.createQuery("CALL mytestProcedure_in_multi(1);");
                ResultIterator<Map<String, Object>> iterator=allResult.cleanupHandle().iterator();
                List<Map<String, Object>> resultList=new ArrayList<>();
                while (iterator.hasNext()){
                    resultList.add(iterator.next());
                }
                List<Map<String, Object>> result = handle.createQuery("CALL mytestProcedure_in_multi(1);").list();
                return result;
            }
        });
    }
}
