package com.apptech.rest.service;

import com.google.inject.Inject;
import com.google.inject.Singleton;
import org.skife.jdbi.v2.DBI;
import org.skife.jdbi.v2.Handle;

import java.util.List;
import java.util.Map;

@Singleton
public class SampleServiceImpl implements SampleService {

    private final DataBaseService dataBaseService;

    @Inject
    public SampleServiceImpl(DataBaseService dataBaseService) {
        this.dataBaseService = dataBaseService;
    }

    @Override
    public String foo() {
        return "Hello World";
    }

    @Override
    public List<Map<String, Object>> getDataFromDb() {
        DBI dbi=dataBaseService.getReadOnlyClient();
        Handle h = dbi.open();
        List<Map<String, Object>> result = h.select("SELECT *,NOW() AS datenow FROM person");
        dbi.close(h);
        return result;
    }

    @Override
    public Map<String, Object> UpdateUsingReadonly() {
        DBI dbi=dataBaseService.getReadOnlyClient();
        Handle h = dbi.open();
        h.update("UPDATE crm_t_user SET systime = NOW();");
        List<Map<String, Object>> result = h.select("SELECT *,NOW() AS datenow FROM person");
        dbi.close(h);
        return result.get(0);
    }

    @Override
    public Map<String, Object> UpdateUsingWriteable() {
        DBI dbi=dataBaseService.getClient();
        Handle h = dbi.open();
        h.update("UPDATE crm_t_user SET systime = NOW();");
        List<Map<String, Object>> result = h.select("SELECT * FROM crm_t_user");
        dbi.close(h);
        return result.get(0);
    }
}
