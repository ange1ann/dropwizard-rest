package com.apptech.rest.module;

import com.apptech.rest.TimberConfiguration;
import com.apptech.rest.annotation.DataReadOnly;
import com.apptech.rest.annotation.DataWriteAble;
import com.google.inject.Binder;
import com.google.inject.Module;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import io.dropwizard.setup.Environment;
import org.skife.jdbi.v2.DBI;
import ru.vyarus.dropwizard.guice.module.support.ConfigurationAwareModule;
import ru.vyarus.dropwizard.guice.module.support.EnvironmentAwareModule;

public class DataBaseModule implements Module, ConfigurationAwareModule<TimberConfiguration>, EnvironmentAwareModule {

    private HikariConfig readOnlyConfig;
    private HikariConfig writeAbleConfig;
    private Environment environment;

    @Override
    public void setConfiguration(TimberConfiguration configuration) {
        this.readOnlyConfig = configuration.getHikaricpConfig(true);
        this.writeAbleConfig = configuration.getHikaricpConfig(false);
    }

    @Override
    public void setEnvironment(Environment environment) {
        this.environment = environment;
    }

    @Override
    public void configure(Binder binder) {
        binder.bind(DBI.class).annotatedWith(DataWriteAble.class).toInstance(writeAbleDBI());
        binder.bind(DBI.class).annotatedWith(DataReadOnly.class).toInstance(readOnlyDBI());
    }

    private DBI writeAbleDBI() {
        writeAbleConfig.setHealthCheckRegistry(environment.healthChecks());
        HikariDataSource dataSource = new HikariDataSource(writeAbleConfig);
        return new DBI(dataSource);
    }

    private DBI readOnlyDBI() {
        readOnlyConfig.setHealthCheckRegistry(environment.healthChecks());
        HikariDataSource dataSource = new HikariDataSource(readOnlyConfig);
        return new DBI(dataSource);
    }
}
