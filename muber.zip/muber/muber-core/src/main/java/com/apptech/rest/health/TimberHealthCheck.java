package com.apptech.rest.health;

import com.codahale.metrics.health.HealthCheck;
import ru.vyarus.dropwizard.guice.module.installer.feature.health.NamedHealthCheck;

public class TimberHealthCheck extends NamedHealthCheck {
    @Override
    protected Result check() throws Exception {
        return Result.healthy("WebService is running");
    }

    @Override
    public String getName() {
        return "AppHealth";
    }
}
