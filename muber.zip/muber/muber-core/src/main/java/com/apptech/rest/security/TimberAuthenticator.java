package com.apptech.rest.security;

import com.apptech.rest.api.User;
import com.google.common.base.Strings;
import com.google.inject.Singleton;
import io.dropwizard.auth.AuthenticationException;

import com.apptech.rest.api.AuthedUser;
import io.dropwizard.auth.Authenticator;

import java.util.Optional;

@Singleton
public class TimberAuthenticator  implements Authenticator<TimberCredentials, AuthedUser> {

    @Override
    public Optional<AuthedUser> authenticate(TimberCredentials credentials) throws AuthenticationException {
        String tokenString = credentials.getToken();
        String userId = TimberAuthResolver.verifyToken(tokenString);
        if (!Strings.isNullOrEmpty(userId)) {
            User user=new User();
            AuthedUser authUser = new AuthedUser(user,tokenString);
            return Optional.of(authUser);
        } else {
            return Optional.empty();
        }
    }
}
