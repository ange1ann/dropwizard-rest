package com.apptech.rest;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.zaxxer.hikari.HikariConfig;
import io.dropwizard.Configuration;

import javax.validation.constraints.NotNull;
import java.util.Properties;

public class TimberConfiguration extends Configuration {

    @NotNull
    @JsonProperty
    private Properties hikaricp;

    public HikariConfig getHikaricpConfig(boolean isReadOnly) {
        HikariConfig config = new HikariConfig();
        config.setReadOnly(isReadOnly);
        config.setJdbcUrl(isReadOnly ? hikaricp.getProperty("readServer") : hikaricp.getProperty("writeServer"));
        config.setPoolName(isReadOnly ? "HIKARI-READONLY-POOL" : "HIKARI-WRITEABLE-POOL");
        config.setUsername(hikaricp.getProperty("dataSourceUser"));
        config.setPassword(hikaricp.getProperty("dataSourcePassword"));
        config.setConnectionTimeout(Long.parseLong(hikaricp.getProperty("connectionTimeout")));
        config.setMaximumPoolSize(Integer.parseInt(hikaricp.getProperty("maximumPoolSize")));
        config.setMaxLifetime(Long.parseLong(hikaricp.getProperty("maxLifetime")));
        config.addDataSourceProperty("cachePrepStmts", hikaricp.get("cachePrepStmts"));
        config.addDataSourceProperty("prepStmtCacheSize", hikaricp.get("prepStmtCacheSize"));
        config.addDataSourceProperty("prepStmtCacheSqlLimit", hikaricp.get("prepStmtCacheSqlLimit"));
        return config;
    }
}
