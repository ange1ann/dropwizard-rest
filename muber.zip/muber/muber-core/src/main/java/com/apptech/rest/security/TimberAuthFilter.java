package com.apptech.rest.security;

import com.apptech.rest.api.AuthToken;
import com.apptech.rest.api.AuthedUser;
import io.dropwizard.auth.AuthFilter;
import io.dropwizard.auth.AuthenticationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import java.io.IOException;
import java.security.Principal;
import java.util.Optional;

public class TimberAuthFilter extends AuthFilter<TimberCredentials, AuthedUser> {

    private static final Logger LOGGER = LoggerFactory.getLogger(TimberAuthFilter.class);

    private static final String AUTHFAIL = "AuthFail";

    @Override
    public void filter(ContainerRequestContext requestContext) throws IOException {
        try {
            // Get the Authorization header
            final String header = requestContext.getHeaderString(HttpHeaders.AUTHORIZATION);
            if (header != null) {
                final AuthToken authTokens = getAuthedToken(header);
                if (authTokens != null) {
                    final TimberCredentials credentials = new TimberCredentials(authTokens.getSignature());
                    final Optional<AuthedUser> result = authenticator.authenticate(credentials);
                    if (result.isPresent()) {
                        requestContext.setSecurityContext(new SecurityContext() {
                            @Override
                            public Principal getUserPrincipal() {
                                return result.get();
                            }

                            @Override
                            public boolean isUserInRole(String role) {
                                return authorizer.authorize(result.get(), role);
                            }

                            @Override
                            public boolean isSecure() {
                                return requestContext.getSecurityContext().isSecure();
                            }

                            @Override
                            public String getAuthenticationScheme() {
                                return SecurityContext.FORM_AUTH;
                            }
                        });

                        return;
                    }
                }
            }

        } catch (IllegalArgumentException e) {
            LOGGER.warn("Error decoding credentials", e);
        } catch (AuthenticationException e) {
            LOGGER.warn("Error authenticating credentials", e);
        } catch (Exception e) {
            LOGGER.warn("Error authenticating process", e);
        }

        // Must have failed to be here
        throw new WebApplicationException(Response.status(Response.Status.UNAUTHORIZED)
                .header(HttpHeaders.AUTHORIZATION,AUTHFAIL)
                .entity("Credentials are required to access this resource.")
                .type(MediaType.TEXT_PLAIN_TYPE)
                .build());
    }

    private AuthToken getAuthedToken(String header) {
        final String[] authTokens = header.split(" ");
        if (authTokens.length != 3) return null;
        return new AuthToken(authTokens[0], authTokens[1], authTokens[2]);
    }

    public static class Builder extends
            AuthFilterBuilder<TimberCredentials, AuthedUser, TimberAuthFilter> {

        @Override
        protected TimberAuthFilter newInstance() {
            return new TimberAuthFilter();
        }
    }
}
